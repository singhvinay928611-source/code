import React, { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { io } from 'socket.io-client';
import './style.css';

const W = 960, H = 520;
const ground = x => 365 + Math.sin(x * .006) * 48 + Math.sin(x * .015 + 1.2) * 20 + Math.sin(x * .0022) * 60;

function GameCanvas({ drive, onStats, restartKey }) {
  const canvasRef = useRef(null);
  const state = useRef({});
  useEffect(() => {
    const s = state.current;
    Object.assign(s, { world: 0, velocity: 0, carY: ground(0)-29, verticalV: 0, angle: 0, angV: 0, fuel: 100, coins: 0, gameOver: false, air: false, last: performance.now(), coinList: [] });
    for(let x=380;x<4900;x+=240) s.coinList.push({x,y:ground(x)-48,taken:false});
  }, [restartKey]);
  useEffect(() => {
    let raf, alive=true;
    const canvas=canvasRef.current, ctx=canvas.getContext('2d');
    function draw(now) {
      if(!alive)return;
      const s=state.current, dt=Math.min((now-s.last)/1000,.035); s.last=now;
      if(!s.gameOver) {
        if(drive.gas && s.fuel>0){s.velocity+=105*dt;s.fuel-=2.6*dt;}else s.velocity-=16*dt;
        if(drive.brake)s.velocity-=150*dt;
        s.velocity=Math.max(0,Math.min(245,s.velocity));
        s.world+=s.velocity*dt;
        const g=ground(s.world), target=g-29, lean=drive.lean||0;
        if(s.carY<target-2){s.air=true;s.verticalV+=480*dt;s.carY+=s.verticalV*dt;s.angV+=lean*2.4*dt;s.angle+=s.angV*dt;}
        else {if(s.air&&Math.abs(s.angle)>.95)s.gameOver=true;s.carY=target;s.verticalV=0;s.air=false;const a=Math.atan((ground(s.world+8)-ground(s.world-8))/16);s.angle+=(a-s.angle)*Math.min(1,dt*9);s.angV*=.75;s.angle+=lean*1.2*dt;}
        if(s.carY>H+80)s.gameOver=true;
        for(const c of s.coinList)if(!c.taken&&Math.abs(c.x-s.world)<35&&Math.abs(c.y-(s.carY-25))<65){c.taken=true;s.coins++;}
      }
      ctx.clearRect(0,0,W,H);
      const sky=ctx.createLinearGradient(0,0,0,H);sky.addColorStop(0,'#72c9f0');sky.addColorStop(1,'#e3f6ff');ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);
      ctx.fillStyle='#8fc9bd';ctx.beginPath();ctx.moveTo(0,H);for(let x=0;x<=W;x+=8)ctx.lineTo(x,300+Math.sin((x+s.world*.18)*.009)*25+Math.sin(x*.02)*9);ctx.lineTo(W,H);ctx.fill();
      ctx.beginPath();ctx.moveTo(0,H);for(let x=0;x<=W;x+=5)ctx.lineTo(x,ground(s.world+x));ctx.lineTo(W,H);ctx.closePath();ctx.fillStyle='#4c9b51';ctx.fill();ctx.strokeStyle='#286c3c';ctx.lineWidth=7;ctx.beginPath();for(let x=0;x<=W;x+=5){const y=ground(s.world+x);x===0?ctx.moveTo(x,y):ctx.lineTo(x,y);}ctx.stroke();
      for(const c of s.coinList){if(c.taken)continue;const x=c.x-s.world;if(x<-20||x>W+20)continue;ctx.fillStyle='#ffd447';ctx.beginPath();ctx.arc(x,c.y,10,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#d28b20';ctx.lineWidth=3;ctx.stroke();}
      ctx.save();ctx.translate(245,s.carY);ctx.rotate(s.angle);ctx.fillStyle='#ed5c48';ctx.strokeStyle='#8d2b2b';ctx.lineWidth=3;ctx.beginPath();ctx.roundRect(-38,-23,76,25,8);ctx.fill();ctx.stroke();ctx.fillStyle='#ffca63';ctx.beginPath();ctx.moveTo(-19,-23);ctx.lineTo(-8,-42);ctx.lineTo(18,-42);ctx.lineTo(31,-23);ctx.closePath();ctx.fill();ctx.stroke();ctx.fillStyle='#a9e5fa';ctx.fillRect(-5,-37,18,12);for(const x of [-24,24]){ctx.fillStyle='#202b3c';ctx.beginPath();ctx.arc(x,3,13,0,Math.PI*2);ctx.fill();ctx.fillStyle='#d7e4ee';ctx.beginPath();ctx.arc(x,3,6,0,Math.PI*2);ctx.fill();}ctx.restore();
      ctx.fillStyle='#1c2d43';ctx.fillRect(20,20,170,18);ctx.fillStyle=s.fuel>25?'#72df87':'#ff6a62';ctx.fillRect(23,23,164*s.fuel/100,12);
      onStats({distance:Math.floor(s.world/10),coins:s.coins,speed:Math.floor(s.velocity/2),fuel:Math.max(0,Math.floor(s.fuel)),gameOver:s.gameOver});
      if(s.gameOver){ctx.fillStyle='#0b1727bb';ctx.fillRect(0,0,W,H);ctx.fillStyle='white';ctx.textAlign='center';ctx.font='bold 44px system-ui';ctx.fillText('Run over!',W/2,H/2-12);ctx.font='20px system-ui';ctx.fillText('Press Restart to try again',W/2,H/2+28);ctx.textAlign='left';}
      raf=requestAnimationFrame(draw);
    }
    state.current.last=performance.now(); raf=requestAnimationFrame(draw);
    return()=>{alive=false;cancelAnimationFrame(raf);};
  }, [drive, onStats]);
  return <canvas ref={canvasRef} width={W} height={H} className="game-canvas" aria-label="Hill climb game" />;
}

function App() {
  const [drive,setDrive]=useState({gas:false,brake:false,lean:0});
  const [stats,setStats]=useState({distance:0,coins:0,speed:0,fuel:100,gameOver:false});
  const [restartKey,setRestartKey]=useState(0);
  const [gesture,setGesture]=useState('off');
  const [gestureStatus,setGestureStatus]=useState('Camera off · keyboard ready');
  const [session,setSession]=useState('Connecting…');
  const [online,setOnline]=useState(0);
  const videoRef=useRef(null), handsRef=useRef(null), cameraRef=useRef(null), keysRef=useRef({});
  const driveRef=useRef(drive);
  useEffect(()=>{driveRef.current=drive;},[drive]);
  const updateStats=React.useCallback(v=>setStats(v),[]);
  useEffect(()=>{
    const socket=io();
    socket.on('connect',()=>setSession('Connected · multiplayer-ready server'));
    socket.on('disconnect',()=>setSession('Offline · game still works'));
    socket.on('online',n=>setOnline(n));
    return()=>socket.disconnect();
  },[]);
  useEffect(()=>{
    const down=e=>{keysRef.current[e.key.toLowerCase()]=true;if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown',' '].includes(e.key))e.preventDefault();if(e.key.toLowerCase()==='r')setRestartKey(k=>k+1);};
    const up=e=>{keysRef.current[e.key.toLowerCase()]=false;};
    window.addEventListener('keydown',down);window.addEventListener('keyup',up);
    const timer=setInterval(()=>{
      const k=keysRef.current;
      if(gesture!=='on')setDrive({gas:!!(k.arrowright||k.d),brake:!!(k.arrowleft||k.a),lean:(k.arrowup||k.w?1:0)-(k.arrowdown||k.s?1:0)});
      else if(!driveRef.current.gestureSeen)setDrive({gas:!!(k.arrowright||k.d),brake:!!(k.arrowleft||k.a),lean:(k.arrowup||k.w?1:0)-(k.arrowdown||k.s?1:0)});
    },30);
    return()=>{clearInterval(timer);window.removeEventListener('keydown',down);window.removeEventListener('keyup',up);};
  },[gesture]);
  async function startGestures(){
    try{
      setGestureStatus('Loading hand-tracking model…');
      const mp=await import('@mediapipe/hands');
      const Hands=mp.Hands || mp.default?.Hands;
      if(!Hands)throw new Error('Hand tracking package could not load');
      const hands=new Hands({locateFile:f=>`https://cdn.jsdelivr.net/npm/@mediapipe/hands/${f}`});
      hands.setOptions({maxNumHands:1,modelComplexity:1,minDetectionConfidence:.6,minTrackingConfidence:.55});
      hands.onResults(results=>{
        const lm=results.multiHandLandmarks?.[0];
        if(!lm){setGestureStatus('No hand detected · show your palm');setDrive(d=>({...d,gas:false,brake:false,gestureSeen:false}));return;}
        const pairs=[[8,6],[12,10],[16,14],[20,18]];
        const extended=pairs.filter(([tip,joint])=>Math.hypot(lm[tip].x-lm[0].x,lm[tip].y-lm[0].y)>Math.hypot(lm[joint].x-lm[0].x,lm[joint].y-lm[0].y)*1.12).length;
        const open=extended>=3, lean=Math.max(-1,Math.min(1,(.5-lm[9].x)*3.2));
        setDrive({gas:open,brake:!open,lean,gestureSeen:true});
        setGestureStatus(open?'Open palm · accelerating':'Fist · braking');
      });
      const stream=await navigator.mediaDevices.getUserMedia({video:{width:640,height:480},audio:false});
      videoRef.current.srcObject=stream;await videoRef.current.play();
      handsRef.current=hands;setGesture('on');setGestureStatus('Camera active · show one hand');
      let busy=false;
      const loop=async()=>{if(!videoRef.current||!handsRef.current||videoRef.current.readyState<2)return;if(!busy){busy=true;try{await handsRef.current.send({image:videoRef.current});}catch(e){}busy=false;}if(cameraRef.current)cameraRef.current=requestAnimationFrame(loop);};
      cameraRef.current=requestAnimationFrame(loop);
    }catch(e){setGestureStatus(`Could not start camera: ${e.message}. Try HTTPS/localhost or keyboard.`);setGesture('off');}
  }
  function stopGestures(){
    if(cameraRef.current)cancelAnimationFrame(cameraRef.current);
    if(videoRef.current?.srcObject)videoRef.current.srcObject.getTracks().forEach(t=>t.stop());
    videoRef.current&&(videoRef.current.srcObject=null);handsRef.current=null;setGesture('off');setDrive({gas:false,brake:false,lean:0});setGestureStatus('Camera off · keyboard ready');
  }
  useEffect(()=>()=>{if(cameraRef.current)cancelAnimationFrame(cameraRef.current);if(videoRef.current?.srcObject)videoRef.current.srcObject.getTracks().forEach(t=>t.stop());},[]);
  return <main className="app">
    <header className="header"><div><div className="eyebrow">ARCADE RACING · HAND TRACKING</div><h1>Gesture <span>Hill Climb</span></h1><p className="subtitle">Big hills. Tiny car. Your hand is the controller.</p></div><div className="server"><span className="live-dot"></span><div><b>{session}</b><small>{online} connected player{online===1?'':'s'}</small></div></div></header>
    <section className="stats">{[['DISTANCE',`${stats.distance} m`],['COINS',stats.coins],['SPEED',stats.speed],['FUEL',`${stats.fuel}%`]].map(([k,v])=><div className="stat" key={k}><small>{k}</small><strong>{v}</strong></div>)}</section>
    <GameCanvas drive={drive} onStats={updateStats} restartKey={restartKey}/>
    <div className="below">
      <section className="panel controls-panel"><div className="panel-heading"><span className="emoji">✋</span><div><h2>Hand controls</h2><p>Allow camera access to drive without touching the keyboard.</p></div></div><div className="gesture-grid"><div className="gesture-card"><span>🖐️</span><b>Open palm</b><small>Accelerate</small></div><div className="gesture-card"><span>✊</span><b>Fist</b><small>Brake</small></div><div className="gesture-card"><span>↔️</span><b>Move sideways</b><small>Lean in the air</small></div></div><div className="actions"><button className="primary" onClick={gesture==='on'?stopGestures:startGestures}>{gesture==='on'?'Turn camera off':'Enable hand controls'}</button><button className="secondary" onClick={()=>setRestartKey(k=>k+1)}>↻ Restart run</button></div><p className="status">{gestureStatus}</p><video ref={videoRef} className="hidden-video" playsInline muted/></section>
      <section className="panel"><div className="panel-heading"><span className="emoji">⌨️</span><div><h2>Keyboard controls</h2><p>Always available as a fallback.</p></div></div><div className="key-list"><div><span className="key">→</span><span className="key">D</span> Accelerate</div><div><span className="key">←</span><span className="key">A</span> Brake</div><div><span className="key">↑</span><span className="key">↓</span> Lean forward / back</div><div><span className="key">R</span> Restart</div></div><div className="note">Camera frames are processed in your browser. This demo doesn't save video.</div></section>
    </div>
    <footer>GESTURE HILL CLIMB <span>Built with React · Vite · Express · Socket.IO · MediaPipe</span></footer>
  </main>;
}
createRoot(document.getElementById('root')).render(<App/>);